/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lakoparkprojekt;

/**
 *
 * @author Diak
 */
public class Lakopark {
    private int[][] hazak;
    private int maxHazSzam; //oszlop
    private String nev;
    private int utcakSzama; //sor

    public Lakopark(int[][] hazak, int maxHazSzam, String nev, int utcakSzama) {
        this.hazak = hazak;
        this.maxHazSzam = maxHazSzam;
        this.nev = nev;
        this.utcakSzama = utcakSzama;
    }

    public int[][] getHazak() {
        return hazak;
    }

    public int getMaxHazSzam() {
        return maxHazSzam;
    }

    public String getNev() {
        return nev;
    }

    public int getUtcakSzama() {
        return utcakSzama;
    }
    
    
}
