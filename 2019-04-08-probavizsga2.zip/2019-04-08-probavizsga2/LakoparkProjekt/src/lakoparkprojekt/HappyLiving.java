/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lakoparkprojekt;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Diak
 */
public class HappyLiving {
    private List<Lakopark> lakoparkok = new ArrayList<>();

    public List<Lakopark> getLakoparkok() {
        return lakoparkok;
    }

    public HappyLiving(String filenev) {
        String line;
        try(BufferedReader br = new BufferedReader(new FileReader(filenev))){
            while((line = br.readLine()) != null){
                while(!line.equals("")){
                    String tempnev = line;
                    String meretek[] = br.readLine().split(";");
                    int utcakSzamatemp = Integer.parseInt(meretek[0]);
                    int maxhHazSzamtemp = Integer.parseInt(meretek[1]);
                    int[][] hazaktemp = new int[utcakSzamatemp][maxhHazSzamtemp];
                    while(!(line = br.readLine()).equals("")){
                        String[] haz = line.split(";");
                        hazaktemp[Integer.parseInt(haz[0])-1][Integer.parseInt(haz[1])-1] 
                                = Integer.parseInt(haz[2]);
                    }
                    
                    Lakopark lp = new Lakopark(hazaktemp, maxhHazSzamtemp, tempnev, utcakSzamatemp);
                    lakoparkok.add(lp);
                }
            }
        
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
    
}
