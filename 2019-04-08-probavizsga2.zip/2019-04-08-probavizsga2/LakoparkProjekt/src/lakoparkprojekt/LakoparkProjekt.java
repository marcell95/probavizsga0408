/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lakoparkprojekt;

/**
 *
 * @author Diak
 */
public class LakoparkProjekt {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //az első és második feladatok vannak csak elkészítve
        FeladatFrame ff = new FeladatFrame();
    }
    
}
