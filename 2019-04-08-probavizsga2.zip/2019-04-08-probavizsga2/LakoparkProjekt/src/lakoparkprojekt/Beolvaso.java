/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lakoparkprojekt;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 *
 * @author Diak
 */
public class Beolvaso {
    private Icon[] kepektomb = new Icon[9];

    public Beolvaso() {
        String kep1 = "balnyil.jpg";
        String kep2 = "Haz1.jpg";
        String kep3 = "Haz2.jpg";
        String kep4 = "Haz3.jpg";
        String kep5 = "jobbnyil.jpg";
        String kep6 = "kereszt.jpg";
        String kep7 = "Puskás Ferenc.jpg";
        String kep8 = "Van Gogh.jpg";
        String kep9 = "Vivaldi.jpg";
        
        Path jelenlegiRelativEleresiUtvonal = Paths.get("");
        String s = jelenlegiRelativEleresiUtvonal.toAbsolutePath().toString();
        FileInputStream stream = null;
        File file = null;
        BufferedImage bi = null;
        
        try{
            file = new File(s + "/Kepek/" + kep1);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[0] = new ImageIcon(atmeretezo(bi, 0.5));
            
            file = new File(s + "/Kepek/" + kep2);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[1] = new ImageIcon(atmeretezo(bi, 0.2));
            
            file = new File(s + "/Kepek/" + kep3);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[2] = new ImageIcon(atmeretezo(bi, 0.2));
            
            file = new File(s + "/Kepek/" + kep4);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[3] = new ImageIcon(atmeretezo(bi, 0.2));
            
            file = new File(s + "/Kepek/" + kep5);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[4] = new ImageIcon(atmeretezo(bi, 0.5));
            
            file = new File(s + "/Kepek/" + kep6);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[5] = new ImageIcon(atmeretezo(bi, 0.5));
            
            file = new File(s + "/Kepek/" + kep7);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[6] = new ImageIcon(atmeretezo(bi, 0.5));
            
            file = new File(s + "/Kepek/" + kep8);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[7] = new ImageIcon(atmeretezo(bi, 0.5));
            
            file = new File(s + "/Kepek/" + kep9);
            stream = new FileInputStream(file);
            bi = ImageIO.read(stream);
            kepektomb[8] = new ImageIcon(atmeretezo(bi, 0.5));
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(FeladatFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(FeladatFrame.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            if(stream == null){
                try {
                    stream.close();
                } catch (IOException ex) {
                    Logger.getLogger(FeladatFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    public Icon getKepektomb(int i) {
        return kepektomb[i];
    }
    
    public BufferedImage atmeretezo(BufferedImage img, double atlag){
        double tempH = img.getHeight();
        double tempW = img.getWidth();
        int ujH = (int)Math.round(tempH * atlag);
        int ujW = (int)Math.round(tempW * atlag);
        
        Image scaled = img.getScaledInstance(ujW, ujH, Image.SCALE_SMOOTH);
        BufferedImage bimg = new BufferedImage(ujW, ujH, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = bimg.createGraphics();
        g2d.drawImage(scaled,0,0, null);
        
        return bimg;
    }
    
    
}
