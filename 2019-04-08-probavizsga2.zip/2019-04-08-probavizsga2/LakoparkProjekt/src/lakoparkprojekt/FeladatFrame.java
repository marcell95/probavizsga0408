/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lakoparkprojekt;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.EnumMap;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Diak
 */
public class FeladatFrame {
    private HappyLiving hl;
    private JFrame frame;
    private JPanel[] parkPanelek = new JPanel[3];
    private JPanel maxiFoPanel;
    private JLabel jobbra;
    private JLabel balra;
    private JButton mentes;
    
    private int parkSzamlalo = 0;
    
    public FeladatFrame() {
        hl = new HappyLiving("lakoparkok.txt");
        Beolvaso beolv = new Beolvaso();
        frame = new JFrame(hl.getLakoparkok().get(1).getNev() + " lakópark");
        
        parkPanelek[0] = ujLakoparkPanel(hl, beolv);
        parkPanelek[1] = ujLakoparkPanel(hl, beolv);
        parkPanelek[2] = ujLakoparkPanel(hl, beolv);
        parkSzamlalo = 1;
        
        maxiFoPanel = new JPanel();
        maxiFoPanel.add(parkPanelek[1]);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add(maxiFoPanel);
        frameFrissites(frame);
        frame.setMinimumSize(frame.getSize());
        frame.setResizable(false);
        frame.setVisible(true);
        
    }
    
    private void frameFrissites(JFrame f){
        f.pack();
        f.validate();
        f.setLocationRelativeTo(null);
    }
    
    private JPanel ujLakoparkPanel(HappyLiving h, Beolvaso beo){
        int rowtemp = h.getLakoparkok().get(parkSzamlalo).getUtcakSzama();
        int coltemp = h.getLakoparkok().get(parkSzamlalo).getMaxHazSzam();
        
        JPanel tablaPanel = new JPanel(new GridLayout(rowtemp, coltemp));
        tablaPanel.setBackground(Color.white);
        
        JLabel[][] iconTabla = new JLabel[rowtemp][coltemp];
        
        MezoKattintas mezokatt = new MezoKattintas();
        int kepindex = 0;
        for (int row = 0; row < iconTabla.length; row++) {
            for (int col = 0; col < iconTabla[row].length; col++) {
                switch(h.getLakoparkok().get(parkSzamlalo).getHazak()[row][col]){
                    case 0: iconTabla[row][col] = new JLabel(beo.getKepektomb(5)); break;
                    case 1: iconTabla[row][col] = new JLabel(beo.getKepektomb(1)); break;
                    case 2: iconTabla[row][col] = new JLabel(beo.getKepektomb(2)); break;
                    case 3: iconTabla[row][col] = new JLabel(beo.getKepektomb(3)); break;
                }
                iconTabla[row][col].setOpaque(true);
                iconTabla[row][col].setBackground(Color.WHITE);
                iconTabla[row][col].addMouseListener(mezokatt);
                tablaPanel.add(iconTabla[row][col]);
            }
        }
        
        JLabel portre = new JLabel(beo.getKepektomb(parkSzamlalo + 6));
        
        JPanel gombokPanel = new JPanel(new BorderLayout());
        GombListener gombkatt = new GombListener();
        JobbraKattintas jobbkatt = new JobbraKattintas();
        BalraKattintas balkatt = new BalraKattintas();
        mentes = new JButton("Mentés");
        mentes.addMouseListener(gombkatt);
        jobbra = new JLabel(beo.getKepektomb(4));
        jobbra.addMouseListener(jobbkatt);
        balra = new JLabel(beo.getKepektomb(0));
        balra.addMouseListener(balkatt);
        
        JPanel jobbrabalra = new JPanel(new BorderLayout());
        if(parkSzamlalo == 0){
            jobbrabalra.add(jobbra, BorderLayout.EAST);
        }else if(parkSzamlalo == 2){   
            jobbrabalra.add(balra, BorderLayout.WEST);
        }else{
            jobbrabalra.add(balra, BorderLayout.WEST);
            jobbrabalra.add(jobbra, BorderLayout.EAST);
        }
        
        gombokPanel.add(mentes, BorderLayout.NORTH);
        gombokPanel.add(jobbrabalra, BorderLayout.SOUTH);
        
        JPanel foPanel = new JPanel(new BorderLayout());
        foPanel.add(tablaPanel, BorderLayout.CENTER);
        foPanel.add(gombokPanel, BorderLayout.SOUTH);
        foPanel.add(portre, BorderLayout.WEST);
        foPanel.setOpaque(false);
        
        parkSzamlalo++;
        
        return foPanel;
    }
    
    private class MezoKattintas extends MouseAdapter{
        @Override
        public void mousePressed(MouseEvent e){
            /*for (int row = 0; row < iconTabla.length; row++){
                for (int col = 0; col < iconTabla[row].length; col++){
                    if (iconTabla[row][col] == e.getSource()){
                        control_tabla.kovEmberiJatekosLepes(row, col, false);
                        System.out.println("katt itt: " + row + ", " + col);
                    }
                }
            }*/
        }
    }
    
    private class JobbraKattintas extends MouseAdapter{
        @Override
        public void mousePressed(MouseEvent e){
            maxiFoPanel.removeAll();
            maxiFoPanel.add(parkPanelek[++parkSzamlalo]);
            frame.setTitle(hl.getLakoparkok().get(parkSzamlalo).getNev() + " lakópark");
            frameFrissites(frame);
        }
    }
    
    private class BalraKattintas extends MouseAdapter{
        @Override
        public void mousePressed(MouseEvent e){
            maxiFoPanel.removeAll();
            maxiFoPanel.add(parkPanelek[--parkSzamlalo]);
            frame.setTitle(hl.getLakoparkok().get(parkSzamlalo).getNev() + " lakópark");
            frameFrissites(frame);
        }
    }
    
    private class GombListener extends MouseAdapter{
        @Override
        public void mousePressed(MouseEvent e){
            if(mentes.getModel().isPressed()){
                
            }
        }
    }
}
